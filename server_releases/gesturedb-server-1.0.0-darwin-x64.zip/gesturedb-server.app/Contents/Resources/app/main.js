'use strict';

const electron = require('electron');
// Module to control application life.
const app = electron.app;
// Module to create native browser window.
const BrowserWindow = electron.BrowserWindow;

var path = require('path');
var displayNotification = require('display-notification');
var Tray = require('tray');
var Menu = require('menu');
var MenuItem = require('menu-item');
var express = require('express');
var express_app = express();
var server;
var tray;
var server_status = "stopped";
var storage = require('./storage');
var ipc = electron.ipcMain;
var bodyParser = require('body-parser');
var async = require('async');
var https = require('https');
//var pem = require('pem');
var pool_count = 0;
var pools = [];
var dbName = {};
express_app.use(bodyParser.json());

if(process.platform === "darwin") {
  app.dock.hide();
}

// Keep a global reference of the window object, if you don't, the window will
// be closed automatically when the JavaScript object is garbage collected.
let mainWindow;

ipc.on('getPort', function(event, arg) {
  console.log(arg);  // prints "ping"
  var port = storage.get('port');
  event.sender.send('portReceived', port);
});

ipc.on('setPort', function(event, arg) {
  console.log('Setting port to' + arg);
  storage.set('port', arg);
  event.sender.send('settingsSaved', arg);
});

ipc.on('getConnections', function(event, arg) {
  var connections = storage.get('connections');
  if(!connections) {
    connections = {};
  }
  event.sender.send('connectionsReceived', connections);
});

ipc.on('addConnection', function(event, arg) {
  console.log("Adding new connection..");
  var connections = storage.get('connections');
  console.log("connections: " + connections);
  if(connections && connections.length>0) {
    connections = JSON.parse(connections);
  } else {
    connections = {};
  }
  var new_connection = JSON.parse(arg);
  if("name" in new_connection && new_connection['name']!= undefined && new_connection['name'] in connections) {
    event.sender.send('error', 'Connection name "' + new_connection.name + '" exists in the database. Please choose a different name and try again.');
  } else if("name" in new_connection && new_connection['name']!= undefined ){
    console.log("Adding connection: " + new_connection['name']);
    var con_name = new_connection['name'];
    connections[con_name] = new_connection;
    var connections_str = JSON.stringify(connections);
    storage.set('connections', connections_str);
    console.log("saving connections: " + connections_str);
    event.sender.send('connectionSaved', null);
  } else {
    event.sender.send('error', 'An unknown error occurred. Please try again!');
  }
});

ipc.on('removeConnection', function(event, arg) {
  console.log("Removing connection " + arg);
  var connections = storage.get('connections');
  if(connections && connections.length>0) {
    connections = JSON.parse(connections);
    var to_remove = arg;
    if(to_remove in connections) {
      delete connections[to_remove];
      var connections_str = JSON.stringify(connections);
      storage.set('connections', connections_str);
      console.log("saving connections: " + connections_str);
      event.sender.send('connectionRemoved', null);
    }
  } else {
    event.sender.send('error', 'An unknown error occurred. Please try again!');
  }
});

function createWindow () {
  if(mainWindow) {
    mainWindow.show();
    return;
  }
  // Create the browser window.
  mainWindow = new BrowserWindow({width: 500, height: 500});

  // and load the index.html of the app.
  mainWindow.loadURL('file://' + __dirname + '/index.html');

  // Open the DevTools.
  //mainWindow.webContents.openDevTools();

  // Emitted when the window is closed.
  mainWindow.on('closed', function() {
    // Dereference the window object, usually you would store windows
    // in an array if your app supports multi windows, this is the time
    // when you should delete the corresponding element.
    mainWindow = null;
  });
}

function start_server() {
  //var port = config.application_port;
  //var port = "3002";
  var port = storage.get('port');

  if(!port) {
    port = "3002"; // Assign a default port
  }

  // pem.createCertificate({days:1, selfSigned:true}, function(err, keys){
  //   if(err) {
  //       console.error(err);
  //       // displayNotification({
  //       //     title: 'GestureDB Error',
  //       //     subtitle: 'Server could not be started'
  //       // });
  //       //system quit?
  //       // return;

  //       // Falling back to http
  //       server = express_app.listen(port, function () {
  //         var host = server.address().address;
  //         var port = server.address().port;
  //         console.log('Server started at http://%s:%s', host, port);

  //         displayNotification({
  //             title: 'GestureDB',
  //             subtitle: 'Server started at http://' + host +  ':' + port
  //         });
  //         server_status = "started";
  //         createTrayMenu();
  //       });
  //   } else {
  //       server = https.createServer({key: keys.serviceKey, cert: keys.certificate}, express_app).listen(port, function() {
  //         var host = server.address().address;
  //         var port = server.address().port;
  //         console.log('Server started at https://%s:%s', host, port);

  //         displayNotification({
  //             title: 'GestureDB',
  //             subtitle: 'Server started at https://' + host +  ':' + port
  //         });
  //         server_status = "started";
  //         createTrayMenu();  
  //       });
  //   }
  // });
  server = express_app.listen(port, function () {
            var host = server.address().address;
            var port = server.address().port;
            console.log('Server started at http://%s:%s', host, port);

            displayNotification({
                title: 'GestureDB',
                subtitle: 'Server started at http://' + host +  ':' + port
            });
            server_status = "started";
            createTrayMenu();
          });
}

function stop_server() {
  server.close();
  server_status = "stopped";
  displayNotification({
      title: 'GestureDB',
      subtitle: 'Server stopped..'
  });
  createTrayMenu();
}

function createTrayMenu() {
  var menu = new Menu();

  var start_menu_item = new MenuItem({
    label: "Start server",
    click: function() {
      start_server();
    }
  });

  var stop_menu_item = new MenuItem({
    label: "Stop server",
    click: function() {
      stop_server();
    }
  });

  if(server_status == "started") {
    start_menu_item.label = "Server is running..";
    start_menu_item.enabled = false;
  } else if(server_status == "stopped") {
    stop_menu_item.enabled = false;
  }

  menu.append(start_menu_item);
  menu.append(stop_menu_item);

  menu.append(new MenuItem({type: 'separator'}));

  menu.append(new MenuItem({
    label: "Settings",
    click: function() {
      createWindow();
    }
  }));

  menu.append(new MenuItem({type: 'separator'}));
  menu.append(new MenuItem({
    label: 'Quit',
    click: app.quit
  }));

  tray.setContextMenu(menu);

  return menu;
}


// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
//app.on('ready', createWindow);
app.on('ready', function () {
  tray = new Tray(path.join(__dirname, '/menubar-icon.png'));
  tray.setPressedImage(path.join(__dirname, 'menubar-icon-alt.png'));

  createTrayMenu();

});

// Quit when all windows are closed.
app.on('window-all-closed', function () {
  // On OS X it is common for applications and their menu bar
  // to stay active until the user quits explicitly with Cmd + Q
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', function () {
  // On OS X it's common to re-create a window in the app when the
  // dock icon is clicked and there are no other windows open.
  if (mainWindow === null) {
    createWindow();
  }
});

express_app.post('/createSelectTable', function (req,res){
  res.set('Content-Type', 'application/json');
  
  var tbName = req.body["tableName"];
  var column = req.body["columnName"];
  var selectText = req.body["selectText"];
  var pool_id = parseInt(req.body["poolId"]);
  if(pool_id < pool_count) {
    var pool = pools[pool_id];
    pool.getConnection(function(err, connection) {
      if(err){
        res.send({"status":"Error: Can't establish connection to database.. Please try again later!"});
        return;
      }
      createSelectTable(res,dbName[pool_id],tbName,selectText,column,connection);
    });
  } else {
    res.send({"status": "Error: Invalid request!"});
  }
});

express_app.post('/createGroupTable', function(req,res){
  res.set('Content-Type', 'application/json');
  
  var tbName = req.body["tableName"];
  var groupBy = req.body["groupBy"];
  var groupType = req.body["groupType"];
  var groupOn = req.body["groupOn"];
  var pool_id = parseInt(req.body["poolId"]);
  if(pool_id < pool_count) {
    var pool = pools[pool_id];
    pool.getConnection(function(err, connection) {
      if(err){
        res.send({"status":"Error: Can't establish connection to database.. Please try again later!"});
        return;
      }
      createGroupTable(res,dbName[pool_id],tbName,groupBy,groupType,groupOn,connection);
    });
  } else {
    res.send({"status": "Error: Invalid request!"});
  }
});

express_app.post('/getCreateStatement', function(req, res) {
  res.set('Content-Type', 'application/json');

  var tbName = req.body["tableName"];
  var pool_id = parseInt(req.body["poolId"]);
  if(pool_id < pool_count) {
    var pool = pools[pool_id];
    pool.getConnection(function(err, connection) {
      if(err){
        res.send({"status":"Error: Can't establish connection to database.. Please try again later!"});
        return;
      }
      getCreateStatement(res,dbName[pool_id],tbName,connection);
    });
  } else {
    res.send({"status": "Error: Invalid request!"});
  }
});

express_app.post('/getConnections', function(req,res){
  res.set('Content-Type', 'application/json');
  res.set('Last-Modified','Wed, 01 Sep 2004 13:24:52 GMT'); 
  var connections = storage.get('connections'); 
  
  if(connections.length > 0) {
    connections = JSON.parse(connections);
  } else  {
    connections = {};
  }

  var result = [];  
  async.forEachOf(connections, function (value, key, callback) {
    
      if (connections.hasOwnProperty(key)) {
        console.log("Getting databases...");
        var tmp_pool = grabNewDBCon( "", connections[key].name, "");
        var options = {
          sql: 'SHOW DATABASES',
          timeout: 40000 // 40s
        };

        tmp_pool.query(options, function(err, rows, fields) {
          tmp_pool.end(function(err) {
            if(err) {
              console.log("Error in closing connections: " + err);
            }
          });
          if(!err){
            var databases = [];  
            for (var i = 0; i < rows.length; i++) {
              databases[i] = rows[i]["Database"];
            }
            console.log("Databases: " + databases.join());
            //res.send(tables);   
            result.push({name: connections[key].name, host: connections[key].host, port: connections[key].port, databases: databases});   
            callback();
          } else {
            console.log("Error in : " + connections[key].name );
            //res.send(["There was an error in fetching databases for one of the saved connections \"" + connections[key].name +"\""]); 
            callback("There was an error in fetching databases for one of the saved connections \"" + connections[key].name +"\"");
            displayNotification({"title":"Error connecting to database","subtitle":"There was an error connecting to '"+connections[key].name+"'"});
          }
        });
      }
    
  }, function (err) {
      if (err) {
        console.error(err.message);
        res.send({"status": "error", "msg": err.message});
      } 
      if(result.length > 0) {
        var conns = JSON.stringify(result);
        //console.log("Conns: " + conns);
        res.send({ "status": "success", "data": result}); 
      } else {
        res.send({"status": "error", "msg": "There are no database connections configured. Add a database connection in server settings to continue."});  
      }
  })
  //res.send({"status": "succ", "test": "success"});
});

express_app.post('/connect', function(req, res){

  var connection_name = req.body["connection_name"]; 
  var database = req.body["database"];  
  var connections = storage.get('connections'); 
  if(connections && connections.length > 0) {
    connections = JSON.parse(connections);
  } else {
    connections = {};
  }
  console.log("Name: " + connection_name);
  //console.log("Connections: " + JSON.stringify(connections));
  if((connection_name in connections) && database) {
    var pool = grabNewDBCon(res, connection_name);
    pools[pool_count++] = pool;
    var pool_id = "" + pool_count-1;
    dbName[pool_id] = database;
    res.send({"status": "success", "poolId": pool_id}); 
  } else {
    res.send({"status": "error", "msg": "Invalid request."}); 
  }

});

express_app.post('/getDataFromTable', function (req, res) {

  res.set('Content-Type', 'application/json');  
  var hunkStart = parseInt(req.body["hunkStart"]);  
  var hunkSize = parseInt(req.body["hunkSize"]);
  var sortBy = req.body["sortBy"];  
  var order = req.body["sortOrder"];
  var tbName = req.body["tableName"];
  var pool_id = parseInt(req.body["poolId"]);
  if(pool_id < pool_count) {
    var pool = pools[pool_id];
    pool.getConnection(function(err, connection) {
      if(err){
        res.send({"status":"Error: Can't establish connection to database.. Please try again later!"});
        return;
      }
      grabChunk(res,tbName,dbName[pool_id],hunkStart,hunkSize,sortBy!=="",sortBy,order,connection);
    });
  } else {
    res.send({"status": "Error: Invalid request!"});
  }

});

express_app.post('/getTables', function (req, res) {

  res.set('Content-Type', 'application/json');

  var pool_id = parseInt(req.body["poolId"]);
  if(pool_id < pool_count) {
    var pool = pools[pool_id];
    pool.getConnection(function(err, connection) {
      if(err){
        res.send({"status":"Error: Can't establish connection to database.. Please try again later!"});
        return;
      }
      var options = {
        sql: 'SELECT DISTINCT table_name from INFORMATION_SCHEMA.tables where table_schema = ? AND table_type = "BASE TABLE" ORDER BY table_name',
        timeout: 40000, // 40s
          values: [dbName[pool_id]],
      };

      connection.query(options, function(err, rows, fields){
        connection.release();
        if(!err){
          var tables = [];    
          for (var i = 0; i < rows.length; i++) {
            tables[i] = rows[i]["table_name"];        //console.log(rows[i]["table_name"]);     
          }
          res.send(tables);   
        } else {
          //Handle this issue...
          res.send(["There was an error..."]);    
        }
      }); 
    });
  } else {
    res.send({"status": "Error: Invalid request!"});
  }
});

function grabChunk(res,tbName,dbName,hunkStart,hunkSize,sorted,sortBy,order,connection){

  var options = {
    sql: 'SELECT column_name from INFORMATION_SCHEMA.columns where table_schema = ? and table_name = ?',
    timeout: 40000, // 40s
      values: [dbName,tbName],
  };  
  console.log("Grabbing chunk: " + options.sql);
  connection.query(options, function(err, rows, fields){
    if(!err){
      var cols = [];
      for(var i = 0; i < rows.length; i++){
        cols[i] = rows[i]["column_name"];
      }

      var sql = "SELECT * from "+dbName+"."+tbName;     
      if(sorted)
        sql+=" ORDER BY `"+sortBy+"` "+order;     
        sql+=" LIMIT "+hunkSize+" OFFSET "+hunkStart;     
        connection.query(sql, function(err, rows, fields) {
          connection.release();
          if(!err){

            for(var i = 0; i < rows.length; i++){
              rows[i] = {
                "data" : rows[i],
                "row_index" : i+hunkStart
              }
            }

            var object = {
              "tableData" : {
                "title" : tbName,
                "rows" : rows,
                "cols" : cols,
              }
            }
            console.log("SQL: " + sql);
            res.send(object);
          } else {
            console.log('Error: ',err);
          }
        });   
    } else {
      console.log('Error: ',err);
    }
  });}

function createGroupTable(res,db,table,groupBy,groupType,groupOn,connection){
  var tmpName = db+"."+table+"Group";
  var dropQuery = "drop view if exists "+tmpName;  
  connection.query(dropQuery, function(err, rows, fields){
    if(!err){
      var dName = db+"."+table;     
      var sClause = "";     
      var factor = "";      
      if(groupType === "SUM"){
        var factor = 'SUM('+groupOn+')';
      }
      else if(groupType=== "COUNT"){
        var factor = 'COUNT(*)';
      }
      else if(groupType=== "MAX"){
        var factor = 'MAX('+groupOn+')';
      }
      else if(groupType=== "MIN"){
        var factor = 'MIN('+groupOn+')';
      }
      
      sClause = ' (SELECT '+factor+',`'+groupBy+'` from '+dName+' GROUP BY `'+groupBy+'`)';
      
      console.log(sClause);     
      var options = {
        sql: 'create view '+tmpName+" as "+sClause,
        timeout: 40000, // 40s
      };      
      connection.query(options, function(err, rows, fields){
        connection.release();
        if(!err){
          res.send({table:table+"Group",cols:[factor,groupBy]});
        }
        else{
          res.send(err);
        }
      });
    }
    else{
      res.send(err);
    }

  });
}

function getCreateStatement(res, dbName, tbName, connection) {
  var query = "SHOW CREATE TABLE " + dbName + "." + tbName;
  connection.query(query, function(err, rows, fields) {
    if(!err) {
      if(rows[0]) {
        var create_mysql_statement = rows[0]["Create Table"];
        console.log("Create: " + create_mysql_statement);
        if(create_mysql_statement) {
          var create_sqlite_statement = convertMysqlToSqlite(create_mysql_statement);
          if(create_sqlite_statement) {
            console.log("Sqlite Statement: " + create_sqlite_statement);
            var json = JSON.parse(create_sqlite_statement);
            res.send(json);
          } else {
            res.send("Error: An error occurred while creating table!"); 
          }
        } else {
          res.send("Error: An error occurred while creating table!");
        }
      }
    }
  });
}

function createSelectTable(res,db,table,text,column,connection){
  var tmpName = db+'.'+table+"Select";
  var dropQuery = "drop view if exists "+tmpName;  
  connection.query(dropQuery, function(err, rows, fields){
    var colTypeQ = "select DATA_TYPE from INFORMATION_SCHEMA.COLUMNS where COLUMN_NAME = '"+column+"' AND TABLE_NAME = '"+table+"' AND TABLE_SCHEMA = '"+db+"'";    connection.query(colTypeQ, function(err, rows, fields){
      if(!err){
        
        var where = "`"+column+"`=?";
        if(rows[0]){
          var type = rows[0]["DATA_TYPE"];
          if(type === "datetime"){
            where = "datediff(`"+column+"`, ?) = 0";
          }
        }
        
        if(text == null){
          //console.log("hiii");
          where = "`"+column+"` IS NULL";
        }

        if(!err){
          var dName = db+"."+table;         
          var options;
          
          console.log("TXT: "+text);          
          if(text !== 'null'){
            options = {
              sql: 'create view '+tmpName+' as (SELECT * from '+dName+' WHERE '+where+")",
              timeout: 40000, // 40s
                values: [text],
            };
          }
          else{
            options = {
              sql: 'create view '+tmpName+' as (SELECT * from '+dName+' WHERE '+where+")",
              timeout: 40000, // 40s
            };
          }

          console.log(options.sql);         
          connection.query(options, function(err, rows, fields){
            connection.release();
            if(!err){
              res.send([table+"Select"]);
            }
            else{
              res.send(err);
            }
          });
        }
        else{
          res.send(err);
        }
      }
      else{
        res.send(err);
      }

    }); 
  }); 
}

function convertMysqlToSqlite(createStatement) {

  createStatement = createStatement.replace(/(\r\n|\n|\r)/gm,"");
  var regex1 = /(CREATE TABLE[\s*|`]+)([^`\s]*)/ig;
  var matches = regex1.exec(createStatement);
  var tableName = matches[2];
  console.log(tableName);
  var regex2 = /KEY[^(]*\(`([^,)"'`]*)/ig;
  matches = regex2.exec(createStatement);
  var indices = new Array();
  while(matches != null) {
    console.log(matches);
    indices.push(matches[1]);
    matches = regex2.exec(createStatement);
  }
  createStatement = createStatement.replace(/auto_increment/gi,'');
    createStatement = createStatement.replace(/character set/gi,'');
    createStatement = createStatement.replace(/default current_timestamp on update current_timestamp/gi,'');
    createStatement = createStatement.replace(/collate/gi,'');
    createStatement = createStatement.replace(/unsigned/gi,'');
    createStatement = createStatement.replace(/enum/gi,'text');
    createStatement = createStatement.replace(/set/gi,'text');
  console.log(indices);
  var ind1 = createStatement.indexOf("(");
  var ind2 = createStatement.lastIndexOf(")");
  var createStatement1 = createStatement.substr(0, ind1+1);
  var createStatement2 = createStatement.substr(ind1+1, ind2-ind1);
  var createStatement3 = createStatement.substr(ind2);
  var arr = createStatement2.split(",");
  for(var i=0;i<arr.length;i++) {
    var regex = / KEY/gi;
    if(regex.exec(arr[i])){
      arr[i] = "";
    }
  }
  createStatement2 = arr.filter(function (val) {return val;}).join(', ');
  createStatement = createStatement1+createStatement2;
  var createIndex = new Array();
  for(var i=0; i<indices.length; i++) {
    createIndex.push("CREATE INDEX \"" + tableName + "_" + indices[i] + "\" ON \"" + tableName + "\" (" + indices[i] + ")");
  }
  var json = {
    create_statement: createStatement,
    create_index: createIndex
  }
  return JSON.stringify(json);
}

// var port = config.application_port;
// var server = express_app.listen(port, function () {

//   var host = server.address().address;  
//   var port = server.address().port; 
//   console.log('Server started at http://%s:%s', host, port);
// });

// process.stdin.resume();//so the program will not close instantly

function exitHandler(options, err) {

  if(pools.length > 0){
    console.log("Ending DB Connections...");     
    for (var i = 0; i < pools.length; i++) {
      pools[i].end(function(err) {
        if(err) {
          console.log("Error in closing pool: " + err);
        }
      });
    }
  }

  if (options.cleanup) console.log('clean');    
  if (err) console.log(err.stack);    
  if (options.exit) process.exit();
}

//do something when app is closing
process.on('exit', exitHandler.bind(null,{cleanup:true}));

//catches ctrl+c event
process.on('SIGINT', exitHandler.bind(null, {exit:true}));

//catches uncaught exceptions
process.on('uncaughtException', exitHandler.bind(null, {exit:true}));

function grabNewDBCon(res,connection_id) {

  var mysql      = require('mysql');  
  var connections = storage.get('connections'); 
  if(connections && connections.length > 0) {
    connections = JSON.parse(connections);
  } else {
    connections = {};
  }
  var connectionInfo = "";  
  connectionInfo = connections[connection_id];  
  var pool  = mysql.createPool({
    connectionLimit : 15,
    host     : connectionInfo.host,
    port     : (connectionInfo.port)?parseInt(""+connectionInfo.port):3306,
    user     : connectionInfo.username,
    password : connectionInfo.password,
  });
  pool.getConnection(function(err, connection) {
    if(err) {
      if(res) {
        res.send({"status": "Error connecting to database"});  
      }
      console.log("Error connecting database ... \n\n");  
      console.log(err);
    } else {
      if(res) {
        res.send({"status": "success"});  
      }
      console.log("Database @ " + connectionInfo.host + "  is connected ... \n\n");
    }
  });
  
  return pool;
}
